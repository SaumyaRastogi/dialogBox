import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import {
  MatButtonModule,
  MatDialogModule
} from '@angular/material';
import { MyCustomDialogService } from './my-custom-dialog.service';
import { MyCustomDialogComponent } from './my-custom-dialog.component';

@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    MatButtonModule,
    MatDialogModule
  ],
  providers: [
    MyCustomDialogService
  ],
  declarations: [
    MyCustomDialogComponent
  ],
  exports: [
    MyCustomDialogComponent
  ],
  entryComponents: [
    MyCustomDialogComponent
  ]
})
export class MyCustomDialogModule {}
