import { Component } from '@angular/core';

@Component({
  selector: 'my-alert-dialog',
  templateUrl: './my-alert-dialog.component.html'
})
export class MyAlertDialogComponent { }